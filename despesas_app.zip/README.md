Este Aplicativo Foi desenvolvido para exibir os valores totais mensais das despesas com cartão de credito / despeas gerais pagas em dinheiro e pix  
